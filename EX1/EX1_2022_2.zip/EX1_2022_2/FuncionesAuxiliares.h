/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesAuxiliares.h
 * Author: cueva
 *
 * Created on 8 de octubre de 2022, 09:46 PM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H
    void imprimeconsultas(void *);
    void imprimemedicinas(void *);
    void imprimerepfinal(void *);
    void ordenareservas(void *); //Ordenamiento por fecha ascendente
#endif /* FUNCIONESAUXILIARES_H */
