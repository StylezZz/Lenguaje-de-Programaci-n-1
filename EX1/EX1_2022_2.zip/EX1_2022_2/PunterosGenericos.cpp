/* 
 * Proyecto: EX1_2022_2
 * Archivo:  PunterosGenericos.cpp
 * Autor: Nombre: Daniel Martin Fiestas Tasayco
 *        Codigo: 20191254
 *
 * Creado el 10 de mayo de 2023, 10:52 AM
 */

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
using namespace std;
#include "PunterosGenericos.h"
#include "FuncionesAuxiliares.h"

void cargamedicinas(void *&medicinas){
    void *buffer[300], **auxMedicina;
    int numDatos=0;
    ifstream archMedicinas("Medicinas.csv", ios::in);
    if(not archMedicinas.is_open()){
        cout<<"Error: No se pudo abrir el archivo Medicinas.csv"<<endl;
        exit(1);
    }
    while(true){
        buffer[numDatos]=leerRegistro(archMedicinas);
        if(buffer[numDatos]==nullptr) break;
        numDatos++;
    }
    auxMedicina=new void*[numDatos+1];
    for(int i=0; i<numDatos+1; i++){
        auxMedicina[i]=buffer[i];
    }
    medicinas=auxMedicina;
    imprimemedicinas(medicinas);
}

void *leerRegistro(ifstream &archMedicinas){
    int cod, *codigo, st, *stock, res=0, *reserva;
    char *nombre, c;
    double pre, *precio;
    void **reg;
    archMedicinas>>cod;
    if(archMedicinas.eof()) return nullptr;
    archMedicinas.get();
    codigo= new int;
    *codigo=cod;
    nombre=leerCadena(archMedicinas, ',');
    stock= new int;
    precio=new double;
    reserva= new int;
    archMedicinas>>*precio>>c>>*stock;
    *reserva=0;
    reg= new void*[5];
    reg[0]=codigo;
    reg[1]=nombre;
    reg[2]=precio;
    reg[3]=stock;
    reg[4]=reserva;
    return reg;
}

char *leerCadena(ifstream &arch, char separador){
    char bufferCad[60], *cadena;
    arch.getline(bufferCad, 60, separador);
    cadena= new char[strlen(bufferCad)+1];
    strcpy(cadena, bufferCad);
    return cadena;
}

void cargaconsultas(void *&citas){
    void *buffer[300], **auxCitas;
    int numCitas=0;
    ifstream archCitas("Consultas.csv", ios::in);
    if(not archCitas.is_open()){
        cout<<"Error: No se pudo abrir el archivo Consultas.csv"<<endl;
        exit(1);
    }
    while(true){
        buffer[numCitas]=leerConsultas(archCitas);
        if(buffer[numCitas]==nullptr) break;
        numCitas++;
    }
    
    auxCitas=new void*[numCitas+1];
    for(int i=0; i<numCitas+1; i++){
        auxCitas[i]=buffer[i];
    }
    citas=auxCitas;
    imprimeconsultas(citas);
}

void *leerConsultas(ifstream &archCitas){
    char cod[10], *nombre, c;
    int *dni, *cantidad, *fecha, dd, mm, aa;
    void **reg;
    archCitas.getline(cod, 10, ',');
    if(archCitas.eof()) return nullptr;
    dni=new int;
    archCitas>>*dni>>c;
    nombre=leerCadena(archCitas, ',');
    cantidad=new int;
    fecha=new int;
    archCitas>>dd>>c>>mm>>c>>aa>>c>>*cantidad>>c;
    *fecha=aa*10000+mm*100+dd;
    reg=new void*[5];
    reg[0]=dni;
    reg[1]=nombre;
    reg[2]=cantidad;
    reg[3]=cargaReceta(archCitas, *cantidad);
    reg[4]=fecha;
    
    return reg;
}

void *cargaReceta(ifstream &archCitas, int n){
    void **auxReg, **reg;
    int *codMedicina, *cantSolicitada;
    char *estado, c;
    
    if(n==0) return nullptr;
    auxReg=new void*[n];
    for(int i=0; i<n; i++){
        reg=new void*[3];
        codMedicina=new int;
        cantSolicitada=new int;
        estado=new char;
        archCitas>>*codMedicina>>c>>*cantSolicitada;
        archCitas.get();
        *estado='S';
        reg[0]=codMedicina;
        reg[1]=cantSolicitada;
        reg[2]=estado;
        auxReg[i]=reg;
    }
    return auxReg;
}

void actualizareservas(void *medicinas, void *cit){
    void **citas=(void **)cit;
    for(int i=0; citas[i]; i++){
        actualizarCita(citas[i], medicinas);
    }
}

void actualizarCita(void *cit, void *medicinas){
    void **cita=(void **)cit;
    int *cantidad=(int *)cita[2];
    if(*cantidad!=0){
        actualizarReservas(cita[3], medicinas, *cantidad);
    }
}

void actualizarReservas(void *cita, void *medicinas, int n){
    void **reserva=(void **)cita;
    int cantReserva, cantStock, codMedicina;
    for(int i=0; i<n; i++){
        cantReserva=buscarReserva(reserva[i]);
        codMedicina=buscarCodigo(reserva[i]);
        cantStock=buscarStock(medicinas, codMedicina);
        if(cantStock>=cantReserva){
            actualizarReserva(reserva[i]);
            actualizarStock(medicinas, codMedicina, cantReserva);
        }
    }
}

int buscarReserva(void *res){
    void **reserva=(void **)res;
    int *cantidad=(int *)reserva[1];
    return *cantidad;
}

int buscarCodigo(void *res){
    void **reserva=(void **)res;
    int *codigo=(int *)reserva[0];
    return *codigo;
}

int buscarStock(void *med, int codMedicina){
    void **medicinas=(void **)med;
    int codMed, stock;
    for(int i=0; medicinas[i]; i++){
        codMed=buscarMedicina(medicinas[i]);
        if(codMed==codMedicina){
            stock=buscarStock(medicinas[i]);
            return stock;
        }
    }
}

int buscarMedicina(void *med){
    void **medicina=(void **)med;
    int *codigo=(int *)medicina[0];
    return *codigo;
}

int buscarStock(void *med){
    void **medicina=(void **)med;
    int *stock=(int *)medicina[3];
    return *stock;
}

void actualizarReserva(void *res){
    void **reserva=(void **)res;
    char *estado=(char *)reserva[2];
    *estado='R';
}

void actualizarStock(void *med, int codMedicina, int cantReserva){
    void **medicinas=(void **)med;
    int codMed;
    for(int i=0; medicinas[i]; i++){
        codMed=buscarMedicina(medicinas[i]);
        if(codMed==codMedicina){
            actualizarCantidad(medicinas[i], cantReserva);
        }
    }
}

void actualizarCantidad(void *med, int cantReserva){
    void **medicina=(void **)med;
    int *stock=(int *)medicina[3];
    int *reserva=(int *)medicina[4];
    
    *reserva+=cantReserva;
    *stock-=cantReserva;
}