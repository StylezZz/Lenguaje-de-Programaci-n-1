/* 
 * File:   PunterosGenericos.h
 * Autor: Nombre: Daniel Martin Fiestas Tasayco
 *        Codigo: 20191254
 *
 * Creado el 10 de mayo de 2023, 10:52 AM
 */

#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H

void cargamedicinas(void *&);
void *leerRegistro(ifstream &);
char *leerCadena(ifstream &, char);
void cortaArreglo(void **&, int);
void cargaconsultas(void *&);
void *leerConsultas(ifstream &);
void *cargaReceta(ifstream &, int);
void actualizareservas(void *, void *);
void actualizarCita(void *, void *);
void actualizarReservas(void *, void *, int);
int buscarReserva(void *);
int buscarCodigo(void *);
int buscarStock(void *, int);
int buscarMedicina(void *);
int buscarStock(void *);
void actualizarReserva(void *);
void actualizarStock(void *, int, int);
void actualizarCantidad(void *, int);

#endif /* PUNTEROSGENERICOS_H */

