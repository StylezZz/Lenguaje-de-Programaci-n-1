/* 
 * Proyecto: EX1_2022_1
 * Archivo:  main.cpp
 * Autor: Nombre: Daniel Martin Fiestas Tasayco
 *        Codigo: 20191254
 *
 * Creado el 10 de mayo de 2023, 10:21 AM
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "FuncionesAuxiliares.h"
#include "PunterosGenericos.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    void *medicinas, *citas;
    
    cargamedicinas(medicinas);
    cargaconsultas(citas);
    ordenareservas(citas);
    actualizareservas(medicinas, citas);
    imprimerepfinal(citas);

    return 0;
}

